# TIGC Black Friday landing page — install guide

## What's in this folder
| File | Goes into (Shopify > Online Store > Themes > ⋯ > Edit code) |
|---|---|
| layout/black-friday.liquid | Layout folder → "Add a new layout" → name it `black-friday` |
| sections/bf-landing.liquid | Sections folder → "Add a new section" → name it `bf-landing` |
| snippets/bf-card.liquid | Snippets folder → "Add a new snippet" → name it `bf-card` |
| templates/page.black-friday.json | Templates folder → "Add a new template" → type *page*, JSON, name `black-friday` |

Paste each file's contents in, replacing the starter code, and save.

**Do this on a duplicate of the live theme first** (Themes → ⋯ → Duplicate), preview it, then publish.

## Make it live
1. Online Store → Pages → Add page → title "Black Friday" → Theme template: `black-friday` → Save.
2. Customize the theme → open that page → pick the collections (main grid, deals, best sellers, limited offers), logo, hero image and sale end time.
3. Set real sale prices by giving products a **Compare-at price** higher than the price. Discount %, badges and savings in the cart are all calculated from that.
4. Optional product tags: `bestseller` or `limited` show those badges on cards.
5. Add customer reviews as "Customer review" blocks, copied from real reviews. Star ratings on cards appear automatically if your review app fills Shopify's standard `reviews.rating` metafield (Judge.me, Loox, Okendo etc. do).

## How subscribers are saved
The popup, newsletter and footer forms use Shopify's built-in customer form. Each signup creates a Shopify customer, subscribes them to email marketing, and adds the tag `black-friday-2026` (changeable in the editor). Nothing is stored in the browser except a "seen popup" cookie so returning visitors aren't asked again.

Already-existing customers who sign up again keep their record, but Shopify doesn't always add the new tag to them. TIGC is on Shopify Plus, so fix this with **Shopify Flow**: trigger "Customer email marketing consent updated" → action "Add customer tags" → `black-friday-2026`.

## Admin dashboard (vikasprasad@digisidekick.com only)
Use Shopify Admin itself as the secure dashboard. Shopify handles login, 2-step verification and permissions on its servers.
1. Settings → Users → Add staff → `vikasprasad@digisidekick.com`. Give access to Customers, Orders, Analytics (and Products if needed). Remove anyone else who shouldn't see it.
2. Customers → Segments → Create segment: `customer_tags CONTAINS 'black-friday-2026'` → save as "Black Friday 2026 subscribers".
   This view gives search, date filters, sorting, customer profiles (orders + total spent), pagination and **Export → CSV**.
3. Analytics → Reports for revenue, orders, conversion rate and new vs returning customers. Filter orders by the customer tag for subscriber-only numbers.

A fully custom dashboard needs a private Shopify app with its own server (Admin API keys can never sit in theme code). That's a separate build.

## Before launch, check
- All default copy (perks, FAQs, banner) matches TIGC's real shipping/returns terms.
- Sale end time is correct (IST, format `2026-11-30T23:59:00+05:30`).
- Test on mobile: popup → signup → add to cart → checkout.
